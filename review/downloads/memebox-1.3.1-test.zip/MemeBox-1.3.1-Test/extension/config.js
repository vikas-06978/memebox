globalThis.MEMEBOX_CONFIG=Object.freeze({SITE_URL:"https://memebox.site",STORE_URL:"https://chromewebstore.google.com/detail/memebox-meme-soundboard-v/bbpfkaedpfabehgikgpagbjhjcmlcpnl",PRO_ENABLED:!0,SHOP_OPEN:!1});

globalThis.MEMEBOX_CONFIG=Object.freeze({...globalThis.MEMEBOX_CONFIG,PLAYER_URL:'http://127.0.0.1:8790/music-room.html'});
